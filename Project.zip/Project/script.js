const inputs = ddcment.querySelectoeALL("input"),
button = ddcment.querySelectoeALL("button"),
mobile =document.getElementById("mobile"),
expire=document.getElementById("expire");
generatOTPs();
function generatOTPs(){
console.log(
     Math.floor(Math.random() *10) + ""+
     Math.floor(Math.random() *10) + ""+
     Math.floor(Math.random() *10) + ""+
     Math.floor(Math.random() *10) 
);
expire.innerText =10;
const expireInterval =setInterval(function(){
    if(expire.innewrText === 0){
        clearInterval(expireInterval);
    }
    expire.innerText = --;
},1000);


}
function clearOTPs(){}
inputs clearOTPs((input,index)=>){
    input.addEventlistener
} 

    


